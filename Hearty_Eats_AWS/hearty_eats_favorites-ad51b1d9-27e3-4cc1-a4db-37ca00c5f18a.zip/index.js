const AWS = require("aws-sdk");
const dynamo = new AWS.DynamoDB.DocumentClient();
exports.handler = (event, context, callback) => {
    let body;
    let response;

    switch (event.routeKey) {
        case 'POST /favorites':
            body = JSON.parse(event.body);

            var params = {
                TableName: 'hearty_eats_favorites',
                KeyConditionExpression: 'restaurant_name = :restaurant_name AND user_name = :user_name',
                ExpressionAttributeValues: {
                    ':restaurant_name': body.restaurant_name,
                    ':user_name': body.user_name
                },
            };

            dynamo.query(params, function(err, result) {
                if (result.Count == 1) return callback(null, { "message": "restaurant has already been added to favorites" });

                if (err) throw err;

                var params = {
                    TableName: 'hearty_eats_favorites',
                    Item: body
                };

                dynamo.put(params, function(err, result) {
                    if (err) throw err;
                    return callback(null, { "message": "added to favorites" });
                });
            });

            break;

        case 'DELETE /favorites/{restaurant_name}/{user_name}':
            var params = {
                TableName: 'hearty_eats_favorites',
                Key: {
                    'restaurant_name': event.pathParameters.restaurant_name,
                    'user_name': event.pathParameters.user_name
                },
            };

            dynamo.delete(params, function(err, result) {
                if (err) throw err;
                return callback(null, { "message": "favorites deleted" });
            });
            break;
            
              case 'GET /favorites/{user_name}':
              var params = {
                  TableName: 'hearty_eats_favorites',
                  KeyConditionExpression: 'user_name = :user_name',
                  ExpressionAttributeValues: {
                      ':user_name': event.pathParameters.user_name,
                  },
              };

              dynamo.query(params, function(err, result) {
                  if (err) throw err;
                  return callback(null, result);
              });
              break;
              
        case 'DELETE /favorites/{user_name}':
            // Verify that the user_name path parameter is present
            if (!event.pathParameters || !event.pathParameters.user_name) {
                return callback(new Error('Missing user_name path parameter'));
            }

            var params = {
                TableName: 'hearty_eats_favorites',
                KeyConditionExpression: 'user_name = :user_name',
                ExpressionAttributeValues: {
                    ':user_name': event.pathParameters.user_name
                }
            };

            // Use the query method to retrieve items with a matching user name
            dynamo.query(params, function(err, result) {
                if (err) {
                    return callback(err);
                }
                var items = result.Items;
                for (var i = 0; i < items.length; i++) {
                    var item = items[i];
                    var deleteParams = {
                        TableName: 'hearty_eats_bookings',
                        Key: {
                            'user_name': item.user_name,
                            'restaurant_name': item.restaurant_name
                        }
                    };
                    // Use the delete method to delete the item
                    dynamo.delete(deleteParams, function(err, result) {
                        if (err) {
                            return callback(err);
                        }
                    });
                }
                return callback(null, { "message": "all favorites deleted" });
            });
            break;
        
         

        default:
            throw new Error("Unsupported route: " + event.routeKey);
    }
}
