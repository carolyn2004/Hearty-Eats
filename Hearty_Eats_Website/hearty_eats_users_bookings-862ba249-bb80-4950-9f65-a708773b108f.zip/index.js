const AWS = require("aws-sdk");
const s3 = new AWS.S3();
const dynamo = new AWS.DynamoDB.DocumentClient();
var lambda = new AWS.Lambda({
    region: 'us-east-1' //change to your region
});
exports.handler = (event, context, callback) => {
    let body;
    let response;

    switch (event.routeKey) {
        case 'POST /user-login':
            body = JSON.parse(event.body);

            var params = {
                TableName: 'hearty_eats_users',
                KeyConditionExpression: 'user_name = :user_name',
                FilterExpression: "password = :password",
                ExpressionAttributeValues: {
                    ':user_name': body.user_name,
                    ':password': body.password
                },
            };

            dynamo.query(params, function(err, result) {
                if (err) throw err;
                return callback(null, result);
            });

            break;

        case 'POST /user-register':
            body = JSON.parse(event.body);

            var params = {
                TableName: 'hearty_eats_users',
                KeyConditionExpression: 'user_name = :user_name',
                ExpressionAttributeValues: {
                    ':user_name': body.user_name,
                },
            };

            dynamo.query(params, function(err, result) {
                if (result.Count == 1) return callback(null, {
                    "message": "user_name already in use!"
                });
                if (err) throw err;
                var params = {
                    TableName: 'hearty_eats_users',
                    Item: body
                };

                dynamo.put(params, function(err, result) {
                    if (err) throw err;
                    return callback(null, { "message": "user added" });
                });
            });

            break;

        case 'PUT /user-profile':
            body = JSON.parse(event.body);

            var params = {
                TableName: 'hearty_eats_users',
                Key: { "user_name": body.user_name },
                UpdateExpression: "set mobile_number = :mobile_number, email = :email,gender = :gender, password = :password",
                ExpressionAttributeValues: {
                    ":mobile_number": body.mobile_number,
                    ":email": body.email,
                    ":gender": body.gender,
                    ":password": body.password,
                },
            }

            dynamo.update(params, function(err, result) {
                if (err) throw err;
                return callback(null, { "message": "user edited" });
            });

            break;

        case 'DELETE /user-profile/{user_name}':
            var params = {
                TableName: 'hearty_eats_users',
                Key: {
                    'user_name': event.pathParameters.user_name,
                },
            };

            dynamo.delete(params, function(err, result) {
                if (err) throw err;
                return callback(null, { "message": "user deleted" });
            });

            break;

        case 'GET /user-profile/{user_name}':
            var params = {
                TableName: 'hearty_eats_users',
                KeyConditionExpression: 'user_name = :user_name',
                ExpressionAttributeValues: {
                    ':user_name': event.pathParameters.user_name,
                },
            };

            dynamo.query(params, function(err, result) {
                if (err) throw err;
                return callback(null, result);
            });

            break;


        case 'GET /bookings/{user_name}':
            var params = {
                TableName: 'hearty_eats_bookings',
                KeyConditionExpression: 'user_name = :user_name',
                ExpressionAttributeValues: {
                    ':user_name': event.pathParameters.user_name,
                },
            };

            dynamo.query(params, function(err, result) {
                if (err) throw err;
                return callback(null, result);
            });

            break;

        case 'POST /bookings':
            body = JSON.parse(event.body);

            var params = {
                TableName: 'hearty_eats_bookings',
                KeyConditionExpression: 'user_name = :user_name AND restaurant_name_date_time = :restaurant_name_date_time',
                ExpressionAttributeValues: {
                    ':user_name': body.user_name,
                    ':restaurant_name_date_time': body.restaurant_name_date_time

                },
            };

            dynamo.query(params, function(err, result) {
                if (result.Count == 1) return callback(null, { "message": "duplicate booking" });

                if (err) throw err;

                var params = {
                    TableName: 'hearty_eats_bookings',
                    Item: body
                };

                dynamo.put(params, function(err, result) {
                    if (err) throw err;
                    return callback(null, { "message": "booking received" });
                });
            });

            lambda.invoke({
                FunctionName: 'arn:aws:lambda:us-east-1:112823250535:function:sns_function',
                Payload: JSON.stringify(event, null, 2) // pass params
            }, function(error, data) {
                if (error) {
                    context.done('error', error);
                }
                if (data.Payload) {
                    context.succeed(data.Payload)
                }
            })

            break;

        case 'DELETE /bookings/{user_name}/{restaurant_name_date_time}':
            var params = {
                TableName: 'hearty_eats_bookings',
                Key: {
                    'user_name': event.pathParameters.user_name,
                    'restaurant_name_date_time': event.pathParameters.restaurant_name_date_time
                },
            };

            dynamo.delete(params, function(err, result) {
                if (err) throw err;
                return callback(null, { "message": "booking cancelled" });
            });

            break;

        case 'DELETE /bookings/{user_name}':
            // Verify that the user_name path parameter is present
            if (!event.pathParameters || !event.pathParameters.user_name) {
                return callback(new Error('Missing user_name path parameter'));
            }

            var params = {
                TableName: 'hearty_eats_bookings',
                KeyConditionExpression: 'user_name = :user_name',
                ExpressionAttributeValues: {
                    ':user_name': event.pathParameters.user_name
                }
            };

            // Use the query method to retrieve items with a matching user name
            dynamo.query(params, function(err, result) {
                if (err) {
                    return callback(err);
                }
                var items = result.Items;
                for (var i = 0; i < items.length; i++) {
                    var item = items[i];
                    var deleteParams = {
                        TableName: 'hearty_eats_bookings',
                        Key: {
                            'user_name': item.user_name,
                            'restaurant_name_date_time': item.restaurant_name_date_time
                        }
                    };
                    // Use the delete method to delete the item
                    dynamo.delete(deleteParams, function(err, result) {
                        if (err) {
                            return callback(err);
                        }
                    });
                }
                return callback(null, { "message": "all bookings deleted" });
            });
            break;
            
            case 'PUT /user-profile-image':
            body = JSON.parse(event.body);
            const fileKey = body.file_key;
            const userName = body.user_name;

             const s3Params = {
                "Bucket": 'uploading-image-bucket',
                "Key": `${userName}.png`,
                "Body": Buffer.from(fileKey, 'base64'),
                "ContentType": 'mime/PNG',
                "ContentEncoding": 'base64',
               
            };
            
            s3.upload(s3Params, (err, data) => {
                if (err) {
                    return callback(err);
                }

                // Get URL of the uploaded file
                const fileUrl = `https://s3.amazonaws.com/${s3Params.Bucket}/${userName}` + '.png';

                // Store URL in DynamoDB
                const dynamoParams = {
                    TableName: 'hearty_eats_users',
                    Key: { "user_name": userName },
                    UpdateExpression: "set file_key = :file_key",
                    ExpressionAttributeValues: {
                        ":file_key": fileUrl,
                    },
                };
                dynamo.update(dynamoParams, (err, result) => {
                    if (err) {
                        return callback(err);
                    }
                    return callback(null, { "message": "file_key and file URL updated" });
                });
            });
            break;

        default:
            throw new Error("Unsupported route: " + event.routeKey);

    }
}
