const AWS = require("aws-sdk");
const dynamo = new AWS.DynamoDB.DocumentClient();
exports.handler = (event, context, callback) => {
    let body;
    let response;

    switch (event.routeKey) {
        case 'GET /restaurants/{restaurant_name}':
            var params = {
                TableName: 'hearty_eats_restaurant_info',
                KeyConditionExpression: 'restaurant_name = :restaurant_name',
                ExpressionAttributeValues: {
                    ':restaurant_name': event.pathParameters.restaurant_name,
                },
            };

            dynamo.query(params, function(err, result) {
                if (err) throw err;
                return callback(null, result);
            });
            break;

        case 'GET /restaurants':
            var params = {
                TableName: 'hearty_eats_restaurant_info'
            };

            dynamo.scan(params, function(err, result) {
                if (err) throw err;
                return callback(null, result);
            });
            break;

        case 'GET /slots/{restaurant_name}':
            var params = {
                TableName: 'hearty_eats_avail_slots',
                KeyConditionExpression: 'restaurant_name = :restaurant_name',
                ExpressionAttributeValues: {
                    ':restaurant_name': event.pathParameters.restaurant_name,
                },
            };

            dynamo.query(params, function(err, result) {
                if (err) throw err;
                return callback(null, result);
            });
            break;

        case 'DELETE /slots/{restaurant_name}/{restaurant_name_date_time}':
            var params = {
                TableName: 'hearty_eats_avail_slots',
                Key: {
                    'restaurant_name': event.pathParameters.restaurant_name,
                    'restaurant_name_date_time': event.pathParameters.restaurant_name_date_time
                },
            };

            dynamo.delete(params, function(err, result) {
                if (err) throw err;
                return callback(null, { "message": "slot deleted" });
            });
            break;

        case 'GET /filterRestaurants/{cuisine}':
            var params = {
                TableName: 'hearty_eats_restaurant_info',
                FilterExpression: "cuisine = :cuisine",
                ExpressionAttributeValues: {
                    ':cuisine': event.pathParameters.cuisine,
                },
            };

            dynamo.scan(params, function(err, result) {
                if (err) throw err;
                return callback(null, result);
            });
            break;

        case 'GET /searchRestaurants/{restaurant_name}':
            var params = {
                TableName: 'hearty_eats_restaurant_info',
                FilterExpression: "contains(#restaurant_name, :restaurant_name)",
                ExpressionAttributeNames: { "#restaurant_name": "restaurant_name" },
                ExpressionAttributeValues: {
                    ':restaurant_name': event.pathParameters.restaurant_name
                },
            };

            dynamo.scan(params, function(err, result) {
                if (err) throw err;
                return callback(null, result);
            });
            break;

        case 'POST /slots':
            body = JSON.parse(event.body);

            var params = {
                TableName: 'hearty_eats_avail_slots',
                KeyConditionExpression: 'restaurant_name = :restaurant_name AND restaurant_name_date_time = :restaurant_name_date_time',
                ExpressionAttributeValues: {
                    ':restaurant_name': body.restaurant_name,
                    ':restaurant_name_date_time': body.restaurant_name_date_time
                },
            };

            dynamo.query(params, function(err, result) {
                if (result.Count == 1) return callback(null, { "message": "duplicate slot" });

                if (err) throw err;


                var params = {
                    TableName: 'hearty_eats_avail_slots',
                    Item: body
                };

                dynamo.put(params, function(err, result) {
                    if (err) throw err;
                    return callback(null, { "message": "slot added" });
                });
            });
            break;

        case 'GET /slots':
            var params = {
                TableName: 'hearty_eats_avail_slots'
            };

            dynamo.scan(params, function(err, result) {
                if (err) throw err;
                return callback(null, result);
            });
            break;

        default:
            throw new Error("Unsupported route: " + event.routeKey);
    }
}
