import json
import boto3

def lambda_handler(event, context):
    # TODO implement
    sns_client = boto3.client('sns')
    sns_client.publish(
        TopicArn='arn:aws:sns:us-east-1:112823250535:sns_topic', 
        Message='A user has made a booking on heart_eats!',
        Subject='Hearty Eats Booking')
    print('sending notification to admin that a booking has been made.')
