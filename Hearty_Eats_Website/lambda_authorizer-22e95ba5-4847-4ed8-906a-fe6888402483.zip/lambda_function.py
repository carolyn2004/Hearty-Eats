import json

def lambda_handler(event, context):
    
    if event['headers']['authorization'] == 'secretcode':
        response = {
            "isAuthorized": True,
            "context": {
                "anyotherparam": "values"
            }
        }
        return response
        
    else: 
        response = {
            "isAuthorized": False,
            "context": {
                "anyotherparam": "values"
            }
        }
        return response
    
   